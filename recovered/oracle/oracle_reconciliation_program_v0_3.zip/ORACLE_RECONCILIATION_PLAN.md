# ORACLE — Unified Integration Reconciliation Program
**Version:** 0.3 · **Mode:** evidence-first, read-only reconciliation · **Entry nodes:** UAH CLI and Integration Automation Network

## North star
An agent or owner can ask **what exists, where it lives, who owns it, how it connects, what is missing, and what is safe to do next** and receive a traceable answer backed by source evidence. UAH CLI is the first audit target and eventual single operational visibility surface; IANG is the optimization and integration-selection node. They gradually converge in one canonical graph without transferring execution authority.

## First milestone: M1 — UAH dispersion reconciled
Produce a complete, reproducible census of UAH and its direct dependency perimeter in SOFTWARE_HQ. The first scan baseline reports 19 files under `integrations/uah/` in the repository-generated `integrations/project.yaml`. This is an *inventory claim*, not independently verified live machine state.

**M1 is complete only when:**
1. All 19 manifest-listed UAH files have a source path, source version/hash or explicit retrieval failure, classification and logical home.
2. Every CLI component is classified as **operational, partial scaffold, design-only, missing, or unknown**, with no assumption that design equals code.
3. All explicit UAH CLI references to CCR/ZCode/OpenCode/ACP Bridge/contracts and reusable engines are typed and source linked.
4. Each cross-boundary relation carries its claimed authority, observed status, confidence, and evidence citation.
5. An absorption backlog identifies what the CLI should **reuse, wrap, defer, or never own**.
6. `oracle_project.yaml` regenerates from SQLite and integrity/coverage tests pass; unresolved records remain explicitly marked.

**M1 excludes:** implementing CLI write commands, altering local services/configuration, exposing endpoints, resolving live host blockers and claiming full cross-repo completion.

## Waves, milestones and evidence
| Wave | Product | Exit gate |
|---|---|---|
| W00 | Source baseline and provenance | Manifest, coverage and identity policy present |
| W01 | Direct UAH + CLI census | Complete 19-file accounting and truthful CLI maturity |
| W02 | Dependency/absorption periphery | Typed source-linked graph and candidate roadmap |
| W03 | Repo-by-repo dispersion | Cross-repo paths and canonical identities |
| W04 | IANG node ingestion | IANG taxonomy and candidates linked without copying authority |
| W05 | Canonical model validation | Stable IDs, referential integrity, status/evidence tests |
| W06 | Execution-ready backlog | Owner-gated, testable and reversible work packages |

Milestones: **M1** UAH dispersion → **M2** cross-repo identity → **M3** two-node convergence → **M4** evidence-gated delivery roadmap. Subsequent adoption and operational proofs require native project authorization.

## Repeatable collection loop
For **one repository at a time**: capture source ref → enumerate tree → detect exact symbol/name hits → inspect semantic references → expand by dependency radius → classify artifacts and relations → preserve original source location → link logical folder node → record gaps/conflicts → validate and regenerate YAML → review next wave. Only source-backed links are confirmed; proposed relationships remain proposed.

## Authority boundaries
- SOFTWARE_HQ: software/application inventories and integration dossiers.
- GPM/IANG: portfolio coordination, network selection, evidence and cross-repository catalog.
- ACP/ZCode: runtime admission, execution and correlated receipts.
- UAH CLI: unified read/plan/stage control-plane view; no unapproved writes, no replacement of ZCode.

## Anti-patterns
- No copying files into a faux monorepo.
- No claiming that a directory manifest proves a runtime works.
- No marking a blocker fixed just because a roadmap task exists.
- No merging aliases without explicit evidence.
- No automatic installation or host configuration change under reconnaissance.
- No fabricated completeness score: publish coverage denominator and exceptions.

## Current measured baseline
SQLite v0.2 had 2 entry initiatives, 23 selected artifacts, 8 typed relationships, 6 UAH CLI phases and a seven-wave plan. The repository-generated `integrations/project.yaml` reported 19 UAH files and 146 integration files. This v0.3 adds milestones and acceptance checks, not a claim of additional scanned files.

## Next work, without further step-by-step prompting
Execute T001→T007 to close M1, then T008–T012 through later milestones. Preserve the existing GPM and SOFTWARE_HQ native status, do not supersede either tracker. A new file should be committed and pushed only when actual repo permissions and conflict/authority checks permit it; otherwise report publication as pending.

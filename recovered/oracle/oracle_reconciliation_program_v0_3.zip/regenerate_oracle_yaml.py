from pathlib import Path
import sqlite3, yaml, datetime
base=Path(__file__).resolve().parent
db=base/'uah_integration_project_v0_3.sqlite3'
out=base/'oracle_project.yaml'
c=sqlite3.connect(db)
p=yaml.safe_load(out.read_text(encoding='utf-8'))
def rows(sql,cols):
    return [dict(zip(cols,r)) for r in c.execute(sql)]
p['milestones']=rows('SELECT * FROM milestones ORDER BY id',['id','title','objective','status','wave_from','wave_to','acceptance_rule','proof_required'])
p['work_items']=rows('SELECT * FROM work_items ORDER BY id',['id','milestone_id','wave_id','title','details','status','owner_domain','prerequisite','output','acceptance'])
p['first_milestone_checks']=rows('SELECT * FROM gate_checks ORDER BY id',['id','milestone_id','requirement','status','evidence_ref'])
p['discovery_rules']=rows('SELECT * FROM discovery_rules ORDER BY depth',['id','depth','rule','classification'])
p['owners']=rows('SELECT * FROM ownership_map',['id','domain','owns','does_not_own'])
p['waves']=[{'id':w,'sequence':seq,'name':title,'status':state,'depends_on':[r[0] for r in c.execute('SELECT depends_on FROM wave_dependencies WHERE wave_id=?',(w,))],'scope':scope,'exit_gate':gate,'artifact_count':c.execute('SELECT COUNT(*) FROM wave_artifacts WHERE wave_id=?',(w,)).fetchone()[0]} for w,seq,title,state,scope,gate in c.execute('SELECT id,sequence,title,status,scope,exit_gate FROM project_waves ORDER BY sequence').fetchall()]
p['inventory']=[]
for aid,path,kind,layer,status,notes in c.execute('SELECT id,path,kind,layer,evidence_status,notes FROM artifacts ORDER BY layer,path').fetchall():
 r=c.execute('SELECT logical_path FROM project_nodes WHERE id=?',('artifact:'+str(aid),)).fetchone()
 p['inventory'].append({'id':f'A{aid:04}','logical_path':r[0] if r else '/Unclassified/'+path.replace('/','__'),'source':{'repo':'SOFTWARE_HQ','path':path,'url':'https://github.com/owenservera/SOFTWARE_HQ/blob/main/'+path},'layer':layer,'kind':kind,'evidence_status':status,'notes':notes})
p['generated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
out.write_text(yaml.safe_dump(p,sort_keys=False,allow_unicode=True,width=110),encoding='utf-8')
print(f'Regenerated {out.name}: {len(p["inventory"])} artifacts, {len(p["milestones"])} milestones')

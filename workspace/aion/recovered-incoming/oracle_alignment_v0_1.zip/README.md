# ORACLE alignment — UAH-first reconciliation workspace

This is a **logical mirror**, not a new deployment or replacement for `integrations/uah/`.

- `mirror/UAH/`: byte-faithful source copies after verified acquisition, no editing of mirrored originals.
- `project.yaml`: concentric circles, wave definitions, source-to-logical mapping, baseline metrics.
- `alignment/TRACKER.md`: status and gate board.
- `alignment/queue.csv`: first measurable signal-driven queue.
- `alignment/signals.json`: baseline metric definitions and readings.
- `program/`: snapshots of existing ORACLE reconciliation artifacts.

**Status:** This local package contains the planned 19-source manifest, but no invented source content. Source text must be imported and hashes verified. The GitHub publication workflow can create the mirrors directly from upstream fetched blobs. No runtime execution or config changes.

# ORACLE alignment tracker — first baseline

| Scope | Baseline | Signal | Status / interpretation |
|---|---:|---|---|
| UAH direct circle | 19 files in repository manifest | mirror_coverage | 0/19 verified in *offline package* (remote source exists) |
| CLI implementation | 3 partial core modules per design | implementation_gap | Entry point, package, registry and tests not verified |
| ACP Bridge | Missing per UAH MAP | blocked_path | Open gate; no install authorized |
| CCR→ZCode | Paused per UAH MAP | blocked_path | User UI action and validation pending |
| IANG integration | second entry node | convergence_gap | Not yet ingested in this wave |

**Queue generation:** high-priority issues arise from missing direct-circle evidence, blocked paths, implementation/documentation divergence and unresolved ownership. These are transparent starting rules, not artificial performance KPIs.

**Light gates:** G0 name+source+ring → G1 source hash+owner+classification → G2 linked dependency+evidence → G3 demonstrated integration outcome. Discovery proceeds even if higher gates remain open.
